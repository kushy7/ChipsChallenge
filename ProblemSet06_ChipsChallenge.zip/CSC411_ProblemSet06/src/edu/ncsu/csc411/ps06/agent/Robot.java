package edu.ncsu.csc411.ps06.agent;

import java.util.ArrayList;
import java.util.Map;

import edu.ncsu.csc411.ps06.environment.Action;
import edu.ncsu.csc411.ps06.environment.Environment;
import edu.ncsu.csc411.ps06.environment.Position;
import edu.ncsu.csc411.ps06.environment.TileStatus;

/**
Represents a planning agent within an environment modeled after
the Chip's Challenge Windows 95 game. This agent must develop a
plan for navigating the environment to collect chips and keys
in order to reach the environment's portal (goal condition).

Problem Set 06 - In this problem set, you will be developing a planning
  agent to navigate the environment to collect chips scattered across the
  map. In order to reach the portal (goal condition), the agent must collect
  all the chips first. In order to do this, the agent will also need to collect
  assorted keys that can be used to unlock doors blocking some of the chips.

  Map difficulties increase by the number of subgoals that the agent must complete.
  While I will be able to assist in getting started debugging, planning is not a 
  simple algorithm and still a complex task for even the most advanced AIs. 
  This of this as one of those "unsolvable" math problems scrawled in chalk on some 
  abandoned blackboard. 
  
  That is to say, you are on your own in this "mostly uncharted" territory.
*/

public class Robot {
	private Environment env;

	/** Initializes a Robot on a specific tile in the environment.
   * @param env - The Environment
   */
  public Robot (Environment env) { this.env = env; }
	
	/**	The method called by Environment to retrieve the agent's actions.        
	    @return should return a single Action from the Action class.
	    	- Action.DO_NOTHING
	    	- Action.MOVE_UP
	    	- Action.MOVE_DOWN
	    	- Action.MOVE_LEFT
	    	- Action.MOVE_RIGHT
	*/
	public Action getAction () {
		/* An initial tip for solving this problem is to review your A* implementations
		 * Since the agent reviews all the steps required to move from their starting 
		 * position to the goal, they will encounter different TileStatus objects 
		 * (namely doors). If the agent's current path needs them to pass through a door,
		 * a new subgoal has been created - unlocking the door.
		 * 
		 * You can get access to the location of all the different objects in the Environment
		 * using the env.getEnvironmentPositions(). This will give you a key-value pair on each
		 * TileStatus to an ArrayList<Position> object, since items like doors, keys, and chips
		 * appear in multiple locations. Review the Environment(String[][] map) constructor to
		 * see all the TileStatus codes.
		 */
		Map<TileStatus, ArrayList<Position>> envPositions = env.getEnvironmentPositions();
		Position goal = envPositions.get(TileStatus.GOAL).get(0);
		ArrayList<Position> chips = envPositions.get(TileStatus.CHIP);
		return Action.DO_NOTHING;
	}

	@Override
	public String toString() {
		return "Robot [pos=" + env.getRobotPosition(this) + "]";
	}
	
	
}